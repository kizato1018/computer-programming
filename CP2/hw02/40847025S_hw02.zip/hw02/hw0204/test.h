#include <stdio.h>
#include <stdint.h>
#pragma once

int fibonacci(int n);
int factorial(int n);