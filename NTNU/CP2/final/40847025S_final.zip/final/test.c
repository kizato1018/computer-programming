#include "fin03.h"

int main() {
    
    sMatrix M;
    init_matrix(&M, 3, 5);
    int32_t cnt = 1;
    
    for(int32_t i = 0; i < 3; ++i) {
        for(int32_t j = 0; j < 3; ++j) {
            // printf("cnt: %d, ", cnt);
            set_matrix(&M, j, i, cnt);
            ++cnt;
        }
    }
    print_matrix(&M);
    free_matrix(&M);
}
